import Badge from '@/ul/Badge/Badge';
import Button from '@/ul/Button/Button';
import Title from '@/ul/Title/Title';
import React from 'react';

const Cta = () => {
	return (
		<section className='cta py-24'>
			<div className='container'>
				<div className='text-center'>
					<Badge text="Let's Work" />
					<Title>Ready to Start Your Project?</Title>
					<p className='max-w-2xl mx-auto mb-6 text-[18px]'>
						Have an idea or need a website built from scratch? I'm open to new
						projects — whether it's a landing page, an online store, or a complex
						web application. Let's discuss the details.
					</p>
					<Button href='/#contact'>Contact me</Button>
				</div>
			</div>
		</section>
	);
};

export default Cta;
