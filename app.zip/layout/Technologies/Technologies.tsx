import Technology from '@/components/Technology/Technology';
import Title from '@/ul/Title/Title';
import React from 'react';

const techs = [
	{ title: 'HTML', image: '/html.png', color: '#e34f26' },
	{ title: 'CSS', image: '/css.png', color: '#264de4' },
	{ title: 'JavaScript', image: '/javascript.png', color: '#f0b429' },
	{ title: 'TypeScript', image: '/ts.png', color: '#3178c6' },
	{ title: 'HTML', image: '/html.png', color: '#e34f26' },
	{ title: 'CSS', image: '/css.png', color: '#264de4' },
	{ title: 'JavaScript', image: '/javascript.png', color: '#f0b429' },
	{ title: 'TypeScript', image: '/ts.png', color: '#3178c6' },
	{ title: 'HTML', image: '/html.png', color: '#e34f26' },
	{ title: 'CSS', image: '/css.png', color: '#264de4' },
	{ title: 'JavaScript', image: '/javascript.png', color: '#f0b429' },
	{ title: 'TypeScript', image: '/ts.png', color: '#3178c6' },
];

const Technologies = () => {
	return (
		<section className='technologies py-24'>
			<div className='container'>
				<div className='text-center mb-12'>
					<Title>Technologies I Use</Title>
					<p className='text-gray-500 max-w-lg mx-auto'>
						Tools and languages I rely on to build fast, modern, and
						maintainable web products.
					</p>
				</div>
				<div className='grid grid-cols-4 gap-4'>
					{techs.map(tech => (
						<Technology
							key={tech.title}
							title={tech.title}
							image={tech.image}
							color={tech.color}
						/>
					))}
				</div>
			</div>
		</section>
	);
};

export default Technologies;
