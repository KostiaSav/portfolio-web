import Gig from '@/components/Gig/Gig';
import Button from '@/ul/Button/Button';
import Title from '@/ul/Title/Title';

const gigs = [
	{
		image:
			'https://cdn.dribbble.com/userupload/15027788/file/original-e93b82e2b7306a74b1cede231c667117.png?resize=400x0',
		title: 'Custom WordPress Business Website',
		description:
			'This project involved the complete development of a modern business website using WordPress and Advanced Custom Fields.',
		imageCount: 2,
		platform: 'wordpress' as const,
	},
	{
		image:
			'https://cdn.dribbble.com/userupload/15027788/file/original-e93b82e2b7306a74b1cede231c667117.png?resize=400x0',
		title: 'WordPress – Lendex',
		description:
			'Developed a fully custom corporate website for a financial services company using WordPress and Elementor.',
		imageCount: 1,
		platform: 'wordpress' as const,
	},
	{
		image:
			'https://cdn.dribbble.com/userupload/15027788/file/original-e93b82e2b7306a74b1cede231c667117.png?resize=400x0',
		title: 'GreenWood – Property Management Website',
		description:
			'Developed a modern, high-performance website for a property management company in Israel.',
		imageCount: 1,
		platform: 'wordpress' as const,
	},
	{
		image:
			'https://cdn.dribbble.com/userupload/15027788/file/original-e93b82e2b7306a74b1cede231c667117.png?resize=400x0',
		title: 'Design & Development',
		description:
			'Full-cycle design and development of a medical startup website with a focus on conversion and trust.',
		imageCount: 1,
		platform: 'fiverr' as const,
	},
	{
		image:
			'https://cdn.dribbble.com/userupload/15027788/file/original-e93b82e2b7306a74b1cede231c667117.png?resize=400x0',
		title: 'Creative Agency Landing Page',
		description:
			'Custom landing page for a creative agency with animations and a modern visual style.',
		imageCount: 2,
		platform: 'wordpress' as const,
	},
	{
		image:
			'https://cdn.dribbble.com/userupload/15027788/file/original-e93b82e2b7306a74b1cede231c667117.png?resize=400x0',
		title: 'E-commerce Store – Outdoor Gear',
		description:
			'Built a fully functional WooCommerce store for an outdoor equipment brand with custom theme and checkout flow.',
		imageCount: 1,
		platform: 'wordpress' as const,
	},
];

const FiverrGigs = () => {
	return (
		<section className='fiverr-gigs pt-24 bg-slate-50'>
			<div className='container'>
				<div className='flex items-end justify-between mb-12'>
					<div>
						<div className='flex items-center gap-2 mb-3'>
							<svg width='20' height='20' viewBox='0 0 24 24' fill='#1dbf73'>
								<path d='M23.004 15.588a.995.995 0 1 0 .002-1.99.995.995 0 0 0-.002 1.99zm-.996-3.705h-1.642c.05-.826.218-1.29.462-1.29.244 0 .434.217.553.543.12.326.193.747.193 1.29h.434zm-3.562 0h-1.656c.05-.826.218-1.29.463-1.29.244 0 .434.217.553.543.12.326.193.747.193 1.29h.447zM12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm-1.42 16.368H8.707v-5.874H7.354v-1.56h1.353V7.57c0-1.681.786-2.57 2.23-2.57.39 0 .772.05 1.143.15v1.52c-.29-.06-.578-.09-.868-.09-.632 0-.932.31-.932.951v1.403h1.775l-.259 1.56H10.28v5.874zm4.965 0h-1.678v-7.434h1.678v7.434zm-.839-8.527c-.54 0-.978-.44-.978-.978s.438-.978.978-.978.978.44.978.978-.437.978-.978.978z' />
							</svg>
							<span className='text-sm font-semibold text-[#1dbf73]'>
								Fiverr Portfolio
							</span>
						</div>
						<Title>Work I've Done for Clients</Title>
						<p className='text-gray-500 max-w-lg'>
							Real projects delivered to real clients. Every item below is a
							completed order from my Fiverr profile.
						</p>
					</div>
					<Button
						href='https://www.fiverr.com/users/kostya_prodan/portfolio'
						type='secondary'
					>
						View all on Fiverr
					</Button>
				</div>
				<div className='grid grid-cols-3 gap-6'>
					{gigs.map(gig => (
						<Gig key={gig.title} {...gig} />
					))}
				</div>
			</div>
		</section>
	);
};

export default FiverrGigs;
