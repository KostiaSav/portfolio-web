import Logo from '@/ul/Logo/Logo';
import Link from 'next/link';
import React from 'react';

const Footer = () => {
	return (
		<footer className='bg-gray-800 text-white'>
			<div className='footer__main py-12'>
				<div className='container'>
					<div className='footer__main__wrapper flex gap-5 justify-between'>
						<div className='flex flex-col gap-4 max-w-[300px]'>
							<Logo />
							<p>
								Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem
								ipsum dolor sit amet.
							</p>

							<div className=' flex gap-3 z-50'>
								<a
									href='https://t.me/your_username'
									target='_blank'
									rel='noopener noreferrer'
									aria-label='Telegram'
									className='w-10 h-10 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform duration-200'
									style={{
										background:
											'linear-gradient(135deg, rgb(42, 171, 238) 0%, rgb(34, 158, 217) 100%)',
									}}
								>
									<svg viewBox='0 0 24 24' fill='white' width='22' height='22'>
										<path d='M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z'></path>
									</svg>
								</a>
								<a
									href='https://wa.me/your_number'
									target='_blank'
									rel='noopener noreferrer'
									aria-label='WhatsApp'
									className='w-10 h-10 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform duration-200'
									style={{
										background:
											'linear-gradient(135deg, rgb(37, 211, 102) 0%, rgb(18, 140, 126) 100%)',
									}}
								>
									<svg viewBox='0 0 24 24' fill='white' width='22' height='22'>
										<path d='M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z'></path>
									</svg>
								</a>
								<a
									href='https://www.fiverr.com/your_username'
									target='_blank'
									rel='noopener noreferrer'
									aria-label='Fiverr'
									className='w-10 h-10 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform duration-200'
									style={{
										background:
											'linear-gradient(135deg, rgb(29, 191, 115) 0%, rgb(25, 164, 99) 100%)',
									}}
								>
									<svg viewBox='0 0 24 24' fill='white' width='22' height='22'>
										<path d='M23.004 15.588a.995.995 0 1 0 .002-1.99.995.995 0 0 0-.002 1.99zm-.996-3.705h-1.642c.05-.826.218-1.29.462-1.29.244 0 .434.217.553.543.12.326.193.747.193 1.29h.434zm-3.562 0h-1.656c.05-.826.218-1.29.463-1.29.244 0 .434.217.553.543.12.326.193.747.193 1.29h.447zM12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm-1.42 16.368H8.707v-5.874H7.354v-1.56h1.353V7.57c0-1.681.786-2.57 2.23-2.57.39 0 .772.05 1.143.15v1.52c-.29-.06-.578-.09-.868-.09-.632 0-.932.31-.932.951v1.403h1.775l-.259 1.56H10.28v5.874zm4.965 0h-1.678v-7.434h1.678v7.434zm-.839-8.527c-.54 0-.978-.44-.978-.978s.438-.978.978-.978.978.44.978.978-.437.978-.978.978z'></path>
									</svg>
								</a>
							</div>
						</div>
						<nav>
							<h3 className='text-lg font-bold mb-5'>Main Links</h3>
							<ul className='flex flex-col gap-4'>
								<li>
									<Link href='/'>Home</Link>
								</li>
								<li>
									<Link href='/'>Projects</Link>
								</li>
								<li>
									<Link href='/'>Technology</Link>
								</li>
								<li>
									<Link href='/'>Freelance</Link>
								</li>
								<li>
									<Link href='/'>Contact</Link>
								</li>
							</ul>
						</nav>

						<nav>
							<h3 className='text-lg font-bold mb-5'>Freelance Links</h3>
							<ul className='flex flex-col gap-4'>
								<li>
									<Link href='/'>Fiverr</Link>
								</li>
								<li>
									<Link href='/'>Upwork</Link>
								</li>
								<li>
									<Link href='/'>FreelanceHunt</Link>
								</li>
							</ul>
						</nav>
					</div>
				</div>
			</div>
			<div className='footer__bottom py-4 bg-gray-900'>
				<div className='container'>
					<p className='footer__text text-[14px] text-center'>
						© 2026 Portfolio. All rights reserved.
					</p>
				</div>
			</div>
		</footer>
	);
};

export default Footer;
