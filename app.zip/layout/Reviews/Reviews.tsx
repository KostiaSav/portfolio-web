import Review from '@/components/Review/Review';
import ReviewPlatform from '@/components/ReviewPlatform/ReviewPlatform';
import Title from '@/ul/Title/Title';

const Reviews = () => {
	return (
		<section className='reviews py-20 bg-gr text-white mt-24'>
			<div className='container'>
				<Title>Reviews</Title>
				<div className='reviews__grid'>
					<div className='reviews__items grid grid-cols-3 gap-3'>
						<Review />
						<Review />
						<Review />
						<Review />
						<Review />
						<Review />
					</div>
					<div className='reviews__socials grid grid-cols-2 gap-4 mt-6'>
						<ReviewPlatform
							platform='fiverr'
							reviewCount={47}
							rating={5.0}
							avatar='/john.jpg'
							name='Prodan Konstantin'
							level='Top Rated Seller'
						/>
						<ReviewPlatform
							platform='freelancehunt'
							reviewCount={23}
							rating={5.0}
							avatar='/john.jpg'
							name='Prodan Konstantin'
							level='PRO Freelancer'
						/>
					</div>
				</div>
			</div>
		</section>
	);
};

export default Reviews;
