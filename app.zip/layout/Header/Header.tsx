import SwitcherTheme from '@/components/SwitcherTheme/SwitcherTheme';
import Logo from '@/ul/Logo/Logo';
import NavLink from '@/ul/Navigation/Link/NavLink';
import Link from 'next/dist/client/link';
import React from 'react';

const Header = () => {
	return (
		<header className='bg-gray-800 text-white py-6 sticky top-0 z-50 backdrop-blur-sm'>
			<div className='container'>
				<div className='flex items-center justify-between gap-4'>
					<Logo />

					<nav className='header__nav'>
						<ul className='nav__list flex items-center gap-6'>
							<NavLink href='/#home' label='Home' isActive={true} />
							<NavLink href='/#projects' label='Projects' />
							<NavLink href='/#technology' label='Technology' />
							<NavLink href='/#reviews' label='Reviews' />
							<NavLink href='/#contact' label='Contact' />
							<SwitcherTheme />
						</ul>
					</nav>
				</div>
			</div>
		</header>
	);
};

export default Header;
