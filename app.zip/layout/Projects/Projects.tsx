import Image from 'next/image';
import './Projects.css';
import Project from '@/components/Project/Project';

const Projects = () => {
	return (
		<section className='projects pt-24'>
			<div className='container'>
				<div className='projects__grid grid grid-cols-3 gap-8'>
					<Project />
					<Project />
					<Project />
				</div>
			</div>
		</section>
	);
};

export default Projects;
